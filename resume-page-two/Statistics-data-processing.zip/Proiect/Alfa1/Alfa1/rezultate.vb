﻿Public Class rezultate
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub rezultate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i As Integer
        Dim ni As Integer
        Dim vector4(100) As Integer
        'marimea intervalului
        Dim vector5(100) As Double
        'densitatea
        Dim vector6(100) As Double
        Dim max As Double
        Dim poz As Double

        'media
        Dim media As Double
        'Mediana
        Dim lme As Double
        Dim med As Double
        Dim x0 As Double
        Dim h As Double
        Dim npme As Double
        Dim nme As Double
        'quartila 1
        Dim lq1 As Double
        Dim q1 As Double
        Dim npq1 As Double
        Dim nq1 As Double
        Dim x0q1 As Double
        'cuartila 2
        Dim lq2 As Double
        Dim q2 As Double
        Dim npq2 As Double
        Dim nq2 As Double
        Dim x0q2 As Double
        'cuartila 3
        Dim lq3 As Double
        Dim q3 As Double
        Dim npq3 As Double
        Dim nq3 As Double
        Dim x0q3 As Double
        'Dispersia/ variata q
        Dim disp As Double



        ni = 0
        Label2.Text = Form1.denumire1
        Label4.Text = Form1.denumire2
        RichTextBox1.Text = ""
        For i = 0 To Form1.n - 1
            RichTextBox1.AppendText(Form1.vector1(i))
            RichTextBox1.AppendText(Environment.NewLine)
        Next
        RichTextBox2.Text = ""
        For i = 0 To Form1.o - 1
            RichTextBox2.AppendText(Form1.vector2(i))
            RichTextBox2.AppendText(Environment.NewLine)
        Next

        RichTextBox3.Text = ""
        For i = 0 To Form1.m - 1
            RichTextBox3.AppendText(Form1.vector3(i))
            RichTextBox3.AppendText(Environment.NewLine)
        Next

        For i = 0 To Form1.m - 1
            ni = Form1.vector3(i) + ni
            RichTextBox4.AppendText(ni)
            RichTextBox4.AppendText(Environment.NewLine)
            vector4(i) = ni
            'marimea intervalului
            vector5(i) = Form1.vector2(i) - Form1.vector1(i)
            RichTextBox6.AppendText(vector5(i))
            RichTextBox6.AppendText(Environment.NewLine)
        Next

        For i = 0 To Form1.o - 1

            RichTextBox5.AppendText((Form1.vector1(i) + Form1.vector2(i)) / 2)
            RichTextBox5.AppendText(Environment.NewLine)
            media = media + ((Form1.vector1(i) + Form1.vector2(i)) / 2) * (Form1.vector3(i))

        Next
        'media sau xcu bara 
        media = media / ni
        TextBox1.Text = media
        'Locul medianei
        lme = (ni + 1) / 2
        TextBox2.Text = lme
        'Mediana
        h = Form1.vector2(1) - Form1.vector1(1)
        'Locul quartilei 1
        lq1 = (ni + 1) / 4
        TextBox3.Text = lq1
        'Locul quartilei 2
        lq2 = 2 * (ni + 1) / 4
        TextBox5.Text = lq2
        'Locul quartilei 3
        lq3 = 3 * (ni + 1) / 4
        TextBox7.Text = lq3


        For i = 0 To Form1.o - 2
            'mediana
            If vector4(i) < lme And vector4(i + 1) > lme Then
                npme = vector4(i)
                x0 = Form1.vector2(i)
                nme = Form1.vector3(i + 1)

            End If
            'cuartila 1
            If vector4(i) < lq1 And vector4(i + 1) > lq1 Then
                npq1 = vector4(i)
                x0q1 = Form1.vector2(i)
                nq1 = Form1.vector3(i + 1)
            End If
            'cuartila 2
            If vector4(i) < lq2 And vector4(i + 1) > lq2 Then
                npq2 = vector4(i)
                x0q2 = Form1.vector2(i)
                nq2 = Form1.vector3(i + 1)
            End If
            'cuartila 3
            If vector4(i) < lq3 And vector4(i + 1) > lq3 Then
                npq3 = vector4(i)
                x0q3 = Form1.vector2(i)
                nq3 = Form1.vector3(i + 1)
            End If
        Next
        med = 0
        med = x0 + h * ((lme - npme) / nme)
        TextBox11.Text = med

        'Quartita 1
        q1 = x0q1 + h * ((lq1 - npq1) / nq1)
        TextBox4.Text = q1
        'Quartita 2
        q2 = x0q2 + h * ((lq2 - npq2) / nq2)
        TextBox6.Text = q2
        'Quartita 3
        q3 = x0q3 + h * ((lq3 - npq3) / nq3)
        TextBox8.Text = q3
        'Total
        TextBox12.Text = ni


        'densitate +Modul
        max = Form1.vector3(0) / vector5(0)
        poz = 0
        For i = 0 To Form1.n - 1
            vector6(i) = Form1.vector3(i) / vector5(i)
            RichTextBox7.AppendText(Form1.vector3(i) / vector5(i))
            RichTextBox7.AppendText(Environment.NewLine)
            If max < vector6(i) Then
                max = vector6(i)
                poz = i
            End If
        Next
        Dim modul As Double

        '0
        'MsgBox(vector5(i) * (vector6(poz) - vector6(poz - 1)))

        modul = Form1.vector1(poz) + (vector5(i) * (vector6(poz) - vector6(poz - 1))) / ((vector6(poz) - vector6(poz - 1)) + (vector6(poz) - vector6(poz + 1)))
        TextBox9.Text = modul

        'Dispersia
        disp = 0
        For i = 0 To Form1.n - 1
            disp = (((Form1.vector1(i) + Form1.vector2(i)) / 2) - media) * (((Form1.vector1(i) + Form1.vector2(i)) / 2) - media) * Form1.vector3(i) + disp
        Next
        disp = disp / ni
        TextBox10.Text = disp
        disp = Math.Sqrt(disp)
        TextBox13.Text = disp

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Grafic.Show()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class