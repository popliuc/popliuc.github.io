﻿Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Citire_date
    Dim APP As New Excel.Application
    Dim worksheet As Excel.Worksheet
    Dim workbook As Excel.Workbook


    Private Sub Citire_date_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)




    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Form1.n = Form1.o Then
            Me.Close()
        Else
            MsgBox("Numarul din cele 2 coloane este diferit  ")
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)






    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)



    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk


    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        Dim myStream As Stream = Nothing
        Dim openFileDialog1 As New OpenFileDialog()

        openFileDialog1.InitialDirectory = "C:\Users\danut\OneDrive\facultate\Anul II\Semestrul I\Statistica\Proiect\"
        openFileDialog1.Filter = "Excel files (*.xlsx)|*.xlsx"
        openFileDialog1.FilterIndex = 2
        openFileDialog1.RestoreDirectory = True

        If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            Try
                myStream = openFileDialog1.OpenFile()
                If (myStream IsNot Nothing) Then
                    'cod pentru preluarea datelor din fisierul Excel
                    'citire tip date 1
                    If Form1.ok = True Then
                        Form1.n = 0
                        Form1.o = 0
                        workbook = APP.Workbooks.Open(openFileDialog1.FileName)
                        worksheet = workbook.Worksheets("Foaie1")
                        TextBox1.Text = openFileDialog1.FileName
                        Dim nume As String
                        nume = worksheet.Cells(1, 1).Value.ToString
                        Label1.Text = nume
                        'transmiterea numelui randului catre main
                        Form1.denumire1 = nume
                        Dim nume1 As String
                        nume1 = worksheet.Cells(1, 2).Value.ToString
                        Label2.Text = nume1
                        'transmiterea numelui randului catre main
                        Form1.denumire2 = nume1
                        RichTextBox1.Visible = True
                        RichTextBox2.Visible = True
                        Dim ok As Integer
                        Dim i As Integer
                        ok = 0
                        i = 2
                        '1
                        Dim LastRow As Long
                        LastRow = worksheet.Range("A1").CurrentRegion.Rows.Count
                        For i = 2 To LastRow
                            Form1.vector1(Form1.n) = worksheet.Cells(i, 1).Value.ToString
                            Form1.n = Form1.n + 1
                        Next
                        '2
                        LastRow = worksheet.Range("B1").CurrentRegion.Rows.Count

                        For i = 2 To LastRow
                            Form1.vector2(Form1.o) = worksheet.Cells(i, 2).Value.ToString
                            Form1.o = Form1.o + 1
                        Next
                        '1 v2
                        RichTextBox1.Text = ""

                        For i = 0 To Form1.n - 1
                            RichTextBox1.AppendText(Form1.vector1(i))
                            RichTextBox1.AppendText(Environment.NewLine)
                        Next
                        '2 v2
                        RichTextBox2.Text = ""
                        For i = 0 To Form1.o - 1
                            RichTextBox2.AppendText(Form1.vector2(i))
                            RichTextBox2.AppendText(Environment.NewLine)
                        Next
                        'inchidere excel
                        workbook.Close()
                    Else
                        Form1.n = 0
                        Form1.o = 0
                        Form1.m = 0
                        workbook = APP.Workbooks.Open(openFileDialog1.FileName)
                        worksheet = workbook.Worksheets("Foaie1")
                        TextBox1.Text = openFileDialog1.FileName
                        Dim nume As String
                        nume = worksheet.Cells(1, 1).Value.ToString
                        Label1.Text = nume
                        'transmiterea numelui randului catre main
                        Form1.denumire1 = nume
                        Dim nume1 As String
                        nume1 = worksheet.Cells(1, 3).Value.ToString
                        Label2.Text = nume1
                        'transmiterea numelui randului catre main
                        Form1.denumire2 = nume1
                        RichTextBox1.Visible = True
                        RichTextBox2.Visible = True
                        RichTextBox3.Visible = True
                        Dim ok As Integer
                        Dim i As Integer
                        ok = 0
                        i = 2
                        '1
                        Dim LastRow As Long
                        LastRow = worksheet.Range("A1").CurrentRegion.Rows.Count
                        For i = 2 To LastRow
                            Form1.vector1(Form1.n) = worksheet.Cells(i, 1).Value.ToString
                            Form1.n = Form1.n + 1
                        Next
                        '2
                        LastRow = worksheet.Range("B1").CurrentRegion.Rows.Count
                        For i = 2 To LastRow
                            Form1.vector2(Form1.o) = worksheet.Cells(i, 2).Value.ToString
                            Form1.o = Form1.o + 1
                        Next
                        '3
                        LastRow = worksheet.Range("C1").CurrentRegion.Rows.Count
                        For i = 2 To LastRow
                            Form1.vector3(Form1.m) = worksheet.Cells(i, 3).Value.ToString
                            Form1.m = Form1.m + 1
                        Next

                        RichTextBox1.Text = ""

                        For i = 0 To Form1.n - 1
                            RichTextBox1.AppendText(Form1.vector1(i))
                            RichTextBox1.AppendText(Environment.NewLine)
                        Next
                        RichTextBox2.Text = ""

                        For i = 0 To Form1.o - 1
                            RichTextBox2.AppendText(Form1.vector2(i))
                            RichTextBox2.AppendText(Environment.NewLine)
                        Next
                        RichTextBox3.Text = ""

                        For i = 0 To Form1.m - 1
                            RichTextBox3.AppendText(Form1.vector3(i))
                            RichTextBox3.AppendText(Environment.NewLine)
                        Next
                        'inchidere excel
                        workbook.Close()

                    End If



                End If
            Catch Ex As Exception
                MessageBox.Show("Cannot read file from disk. Original error: " & Ex.Message)
            Finally
                ' Check this again, since we need to make sure we didn't throw an exception on open.
                If (myStream IsNot Nothing) Then
                    myStream.Close()
                End If
            End Try
        End If

    End Sub



End Class