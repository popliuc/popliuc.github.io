﻿Imports System.Data.OleDb
Public Class Form1
    Dim provider As String
    Dim dataFile As String
    Dim connString As String
    Dim myConnection As OleDbConnection = New OleDbConnection

    'tip 1 de date
    Public n As Integer
    Public o As Integer
    Public vector2(100) As Integer
    Public vector1(100) As Integer

    'tip 2 de date
    Public m As Integer
    Public vector3(100) As Integer

    'transmitere denumirilor fiecarei linii
    Public denumire1 As String
    Public denumire2 As String
    'pentru citirea corespunzatoare in functie de tipul de date dorite
    Public ok As Boolean




    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        provider = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source ="
        'locatia bazei de date 
        dataFile = "C:\Users\danut\OneDrive\facultate\Anul II\Semestrul I\Statistica\Proiect\logare.mdb"

        connString = provider & dataFile
        myConnection.ConnectionString = connString

        myConnection.Open()
        Dim cmd As OleDbCommand = New OleDbCommand("SELECT * FROM [users] WHERE [username] = '" & UsernameTextBox.Text & "' AND [password] = '" & PasswordTextBox.Text & "'", myConnection)
        Dim dr As OleDbDataReader = cmd.ExecuteReader

        ' the following variable is hold true if user is found, and false if user is not found
        Dim userFound As Boolean = False

        While dr.Read
            userFound = True

        End While
        'checking the result
        If userFound = True Then
            main.Show()
        Else
            MsgBox("Eroare nume sau parola invalida ", MsgBoxStyle.OkOnly, "Eroare")
        End If

        myConnection.Close()

    End Sub
End Class
