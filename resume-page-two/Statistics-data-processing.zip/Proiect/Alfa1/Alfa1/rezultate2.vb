﻿Public Class rezultate2
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub rezultate2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i As Integer
        Dim ni As Integer
        Dim vector3(100) As Integer
        'media
        Dim media As Double
        'Mediana
        Dim lme As Double
        Dim med As Double
        'Quartilele
        Dim lq1 As Double
        Dim lq2 As Double
        Dim lq3 As Double
        Dim max As Double
        Dim poz As Double
        'q
        Dim q As Double
        'dispersia , q 
        Dim disp As Double
        disp = 0
        max = Form1.vector1(0)
        poz = 0
        Label1.Text = Form1.denumire1
        Label2.Text = Form1.denumire2
        RichTextBox1.Text = ""
        For i = 0 To Form1.n - 1
            RichTextBox1.AppendText(Form1.vector1(i))
            RichTextBox1.AppendText(Environment.NewLine)
        Next
        RichTextBox2.Text = ""
        media = 0
        For i = 0 To Form1.o - 1
            RichTextBox2.AppendText(Form1.vector2(i))
            RichTextBox2.AppendText(Environment.NewLine)
            media = media + (Form1.vector1(i) * Form1.vector2(i))
            If Form1.vector1(i) > max Then
                max = Form1.vector1(i)
                poz = i

            End If
        Next
        'ni ul 
        ni = 0
        For i = 0 To Form1.o - 1
            ni = Form1.vector2(i) + ni
            RichTextBox3.AppendText(ni)
            RichTextBox3.AppendText(Environment.NewLine)
            vector3(i) = ni

        Next
        'Total
        TextBox10.Text = ni
        'Media
        media = media / ni
        TextBox1.Text = media
        'Quartilele
        lq1 = (ni + 1) / 4
        lq2 = 2 * (ni + 1) / 4
        lq3 = 3 * (ni + 1) / 4
        TextBox4.Text = lq1
        TextBox6.Text = lq2
        TextBox8.Text = lq3
        'Locul medianei+ locul quartilelor
        lme = (ni + 1) / 2
        TextBox2.Text = lme
        For i = 0 To Form1.o - 1
            If vector3(i) <= lme Then
                If vector3(i) = lme Then
                    med = Form1.vector1(i)
                Else
                    med = Form1.vector1(i + 1)

                End If
            End If

            If vector3(i) <= lq1 Then
                If vector3(i) = lq1 Then
                    TextBox5.Text = Form1.vector1(i)
                Else
                    TextBox5.Text = Form1.vector1(i + 1)
                End If
            End If
            If vector3(i) <= lq2 Then
                If vector3(i) = lq2 Then
                    TextBox7.Text = Form1.vector1(i)
                Else
                    TextBox7.Text = Form1.vector1(i + 1)
                End If

            End If
            If vector3(i) <= lq3 Then
                If vector3(i) = lq3 Then
                    TextBox9.Text = Form1.vector1(i)
                Else
                    TextBox9.Text = Form1.vector1(i + 1)
                End If
            End If
        Next
        TextBox3.Text = med
        'Modul
        TextBox11.Text = Form1.vector2(poz)

        'q
        For i = 0 To Form1.o - 1
            q = q + ((Form1.vector2(i) - media) * (Form1.vector2(i) - media) * Form1.vector1(i))
        Next
        q = q / ni
        q = Math.Sqrt(q)

        TextBox12.Text = q

        'Dispersia
        For i = 0 To Form1.o - 1
            disp = disp + (Form1.vector1(i) - media) * (Form1.vector1(i) - media) * Form1.vector2(i)
        Next
        disp = disp / ni
        TextBox13.Text = disp
        disp = Math.Sqrt(disp)
        TextBox14.Text = disp
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class