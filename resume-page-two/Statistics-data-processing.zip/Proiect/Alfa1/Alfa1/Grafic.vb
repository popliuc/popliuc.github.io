﻿Public Class Grafic
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Grafic_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i As Integer
        For i = 0 To Form1.o - 1
            Me.Chart1.Series("Series1").Points.AddY(Form1.vector3(i))
        Next

        'schimbare  nume 
        Me.Chart1.Series("Series1").Name = Form1.denumire2

    End Sub

    Private Sub Chart1_Click(sender As Object, e As EventArgs) Handles Chart1.Click

    End Sub
End Class